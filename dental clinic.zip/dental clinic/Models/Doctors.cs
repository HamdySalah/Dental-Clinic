﻿namespace dental_clinic.Models
{
    public class Doctors
    {
        public int ID { get; set; }
        public string name { get; set; }
        public string Email { get; set; }
        public string Email_pass { get; set; }
        public string phonNumber { get; set; }
    }
}
