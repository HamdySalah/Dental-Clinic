﻿namespace dental_clinic.Models
{
    public class paitents
    {
        public int ID { get; set; }
        public string name { get; set; }
        public string Email { get; set; }
        public string Email_pass { get; set; }
        public string phonNumber { get; set; }
        public int age { get; set; }
        public string Addres { get; set; }
    }
}
